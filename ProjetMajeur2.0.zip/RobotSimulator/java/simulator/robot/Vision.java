package simulator.robot;

import java.util.LinkedList;
import java.util.List;

import simulator.env.Point;

/**
 * This class represents a vision
 * Giving an orientation and x,y coords,
 * the vision have a List of visible Points
 * @author mathieu lai-king
 *
 */
public class Vision {
	/*
	 * Attributs
	 */

	private List<Point> visiblePts;
	
	private Point coord;
	private Orientation orientation;
	
	public Vision(Point coord,Orientation o) {
		super();
		this.coord=coord;
		this.orientation=o;
		this.visiblePts = this.generateVision(this.coord, this.orientation,2);
	}
	
	public List<Point> getVisiblePts() {
		return visiblePts;
	}


	private List<Point> generateVision(Point coord,Orientation o,int visionRange) {
		List<Point> visibleCases = new LinkedList<Point>() ;
		for (int i=1;i<=visionRange;i++) {
			if (o==Orientation.N) {
				visibleCases.add(new Point((int)coord.getX(),(int)coord.getY()-i));
			}
			else if (o==Orientation.E) {
				visibleCases.add(new Point((int)coord.getX()+i,(int)coord.getY()));
			}
			else if (o==Orientation.S) {
				visibleCases.add(new Point((int)coord.getX(),(int)coord.getY()+i));
			}
			else if (o==Orientation.W) {
				visibleCases.add(new Point((int)coord.getX()-i,(int)coord.getY()));
			}
		}
		return visibleCases;
	}

	
	@Override
	public String toString() {
		return "Vision [visiblePts=" + visiblePts + "coord = "+coord+"orientation = "+orientation+"]";
	}
	

}
