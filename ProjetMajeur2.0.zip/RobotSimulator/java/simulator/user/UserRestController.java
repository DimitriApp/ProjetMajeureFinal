package simulator.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserRestController {
	

	@Autowired
	private UserService userService;
	
	
	/**
	 * Get user in database
	 * @param user
	 */
	@RequestMapping(method=RequestMethod.GET,value="/user/{id}")
	public User addUser(@PathVariable int id) {
		return userService.getUserById(id);
	}
	
	
	/**
	 * Add user in database
	 * @param user
	 */
	@RequestMapping(method=RequestMethod.POST,value="/user")
	public String addUser() {
		User u = new User();
		userService.addUser(u);
		return u.getId().toString();
	}
	
//	/**
//	 * remove 1 user in database
//	 * @param iduser
//	 */
//	@RequestMapping(method=RequestMethod.DELETE,value="/user/{id}")
//	public String removeUser (@PathVariable Integer id ) {
//		userService.removeUser(id);
//		return id.toString(id);
//	}
}