class Robot {
    // méthode constructor
    constructor() {
    	this.x = 0;
		this.y = 0;
		this.setCoord;
    }
    
//    setCoord(){   
//    	$.ajax({
//  		   url: '/robots/coords', 
//  		   type : 'GET', 
//  		   dataType : 'JSON', 
//	        async: false,
//	        cache: false,   ////WTF IS THIS
//	        timeout: 30000,
//  		   // contentType:'application/json',
//  		   success : function(response/* , textStatus */) {
//  			   this.x = response[0].x;
//  			   this.y = response[0].y;
//  		   },
//  		   error: function(xhr, resp, text) {
//  		       console.log(xhr, resp, text);
//  		   }
//    	});
//    	//return 
//    }

    sayCoord() {
        return `${this.x} ${this.y}`;
    }

    getX()
    {
        return `${this.x}`;
    }getY()
    {
        return `${this.y}`;
    }
    setX(x)
    {
        this.x = x;
    }setY(y)
    {
        this.y = y;
    }
}


export {Robot};