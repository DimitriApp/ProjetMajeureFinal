package simulator.admin;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
	
	@Autowired
	private AdminRepository adminRepository;
	
	/**
	 * Return all the admins in database
	 * @return
	 */
	public List<Admin> getAllAdmin() {
		List<Admin> admins = new ArrayList<>();
		adminRepository.findAll().forEach(admins::add);
		return admins;
	}
	/**
	 * Return Admin by id
	 * @param id
	 * @return
	 */
	public Admin getAdminById(Integer id) {
		return adminRepository.findById(id);
	}
	
	/**
	 * Add user to database if username not taken
	 * @param admin
	 * @return
	 */
	public boolean addAdmin(Admin admin) {
		Admin u = adminRepository.findByName(admin.getName());
		if (u == null) {
			adminRepository.save(admin);
			return true;
		}
		else {
			return false;
		}		
	}
	
	/**
	 * Return true if the user parameters are matching false if not
	 * @param admin
	 * @return
	 */
	public boolean possibleAdminConnect(String name, String password) {
		boolean ret = false;
		Admin adminconnection = adminRepository.findByNameAndPassword(name, password);
		
		if (adminconnection != null) {
			ret = true ;
		}
		return ret;
	}
	
	/**
	 * Return Admin by name
	 * @param admin
	 * @return
	 */
	public Admin getAdminByName(Admin admin) {
		return adminRepository.findByName(admin.getPassword());
	}
	
}