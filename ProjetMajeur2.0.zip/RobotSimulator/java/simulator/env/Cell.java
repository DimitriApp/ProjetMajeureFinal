package simulator.env;

/**
 * Enumeration representing a Cell : FREE,OBSTACLE,UNKNOWN // UNKNOWN is used
 * only by the robot environment
 * 
 * @author mattk
 *
 */
public enum Cell {
	FREE, OBSTACLE, UNKNOWN
}
