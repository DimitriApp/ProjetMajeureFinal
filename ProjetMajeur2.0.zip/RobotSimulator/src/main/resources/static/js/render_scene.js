import {MapMng} from './classes/MapMng.js';
import {Robot} from './classes/Robot.js';
$(document).ready(function(){ 
	document.onkeydown = checkKey;

	function checkKey(e) {
		console.log("check")
	    e = e || window.event;

	    if (e.keyCode == '38') {
	    	console.log("up")
	        // up arrow
	    	askMove("up");
	    }
	    else if (e.keyCode == '40') {
	        // down arrow
	    	askMove("down");
	    }
	    else if (e.keyCode == '37') {
	       // left arrow
	    	askMove("left");
	    }
	    else if (e.keyCode == '39') {
	       // right arrow
	    	askMove("right");
	    }

	}
	
	var id =0;
	var allow_command=false;
	
	$.ajax({ 
        method:'POST',
		url:'/user', 
        dataType:'text',
        success: function (response) {
        	id = response;
        	// document.cookie="id="+response;
        	console.log(id)
        },
        error: function (xhr, ajaxOptions, thrownError) {
        	alert("Error post");
        }
    }); 
			
	$.ajax({ 
        method:'GET',
		url:'/robot/state',
        dataType:'text',
        success: function (response) {
          	console.log("state: ",response) // state robot
          	if (response=="enable"){
          		toggleDisplayOn("enable");
          	}
          	else {
          		toggleDisplayOn("disable");
          	}

        },
        error: function (xhr, ajaxOptions, thrownError) {
        	alert("Error get state");
        }
    }); 
	
  	$("#staterobot").click(function(){
		$.ajax({ 
            method:'GET',
    		url:'/robot/state',
            dataType:'text',	
            success: function (response) {
            	console.log("etat:" ,response,"id: ",id)
              	if (response=="enable"){ // enable --> running, disable for
											// others
              		$.ajax({ 
                        method:'PUT',
                		url:'/robot', 
                		data:id,
                        contentType:'text/plain	',
                        success: function () {
                        	console.log("Success disable");
                        	allow_command = true;
                      		toggleDisplayOn("running");
                      		toggleDisplayOff("enable");
                      		toggleDisplayOff("disable");
                        },
                        error: function (xhr, ajaxOptions, thrownError) {
                        	console.log(xhr, ajaxOptions, thrownError);
                        	alert("Error set run");
                        }
                    });
              	}
              	else if (response == id){ // runnning --> enable for all
              		$.ajax({ 
                        method:'PUT',
                		url:'/robot', 
                        data : 'enable', // disable robot
                        contentType:'text/plain',
                        success: function () {
                        	allow_command = false;
                        	console.log("Success enable");
                      		toggleDisplayOff("running");
                      		toggleDisplayOn("enable");
                      		toggleDisplayOff("disable");
                        },
                        error: function (xhr, ajaxOptions, thrownError) {
                        	console.log(xhr, ajaxOptions, thrownError);
                        	alert("Error run_2_enab");
                        }
                    });
              	}
              	else if (response== "disable" || response!=id){ // disable
              		console.log("Disable")
              		toggleDisplayOff("enable");
              		toggleDisplayOn("disable");
              		toggleDisplayOff("running");
              		allow_command=false;
              	}
            },
            error: function (xhr, ajaxOptions, thrownError) {
            	alert("Error get state");
            }
        });
    });
  	


	
	
	// ////////////////////////////////////////////////////////
	
	
	// cb reference
	var cbShObstacle = document.querySelector('input[id="cbShowObstacle"]');
	var cbShPath = document.querySelector('input[id="cbShowPath"]');
	var cbShRobot = document.querySelector('input[id="cbShowRobot"]');
	
	// imgCodes
	var imgCodeObstacle = 100;var imgCodeFree = 82;var imgCodeUnknown = 27;var imgCodeRobot = 136;
	var imgCodePathV = 126;var imgCodePathH = 127;var imgCodePathUpLeft = 139;var imgCodePathLeftDown = 122;var imgCodePathDownRight = 121;var imgCodePathRightUp = 138;
	
	var mapMng = new MapMng();
	const sizemap = 50;
	
	var knownEnv = {};
	var displayedEnv = {};
	
	var robot = new Robot();
	
	$(function() {
	    // out of scope ?
	    let rightButton = document.getElementById('right');
	    let leftButton = document.getElementById('left');
	    let upButton = document.getElementById('up');
	    let downButton = document.getElementById('down');
	    
		MapInit();
	
	    $(document).on('input change', '#scaleButtonId', function() {
	        var current_val=$("#scaleButtonId")[0].value;
	        mapMng.scale_factor=current_val;
	        mapMng.rerenderall();  
	    });
	
	    rightButton.onclick = function () {  
	    	askMove("right");
	    };
	    leftButton.onclick = function () {  
	    	askMove("left");
	    };
	    upButton.onclick = function () {  
	    	askMove("up");
	    };
	    downButton.onclick = function () {  
	    	askMove("down");
	    };
	    
	    cbShPath.onchange = function() {
	    	cbChanges(knownEnv);
		   // Final Render
		   Display();
	  	};
	  	cbShRobot.onchange = function() {
	  		cbChanges(knownEnv);
		   // Final Render
		   Display();
	  	};
	  	cbShObstacle.onchange = function() {
	  		cbChanges(knownEnv);
		   // Final Render
		   Display();
	  	};
	  	
	  	askEnvRobot();
	});
	
	function MapInit(){
		var c = $("canvas")[0].getContext("2d");
	
	    mapMng = new MapMng(c, []);
	    mapMng.load("3em_map");
	
	    mapMng.scale_factor=1; // Pour avoir toute la carte
	}
	
	function setRobotCoord(){
		let bot = new Robot();
		$.ajax({
			   url: '/robots/coords', 
			   type : 'GET', 
			   dataType : 'JSON', 
		     async: false,
		     cache: false,   // //WTF IS THIS
		     timeout: 30000,
			   // contentType:'application/json',
			   success : function(response/* , textStatus */) {
				   bot.x = response.x;
				   bot.y = response.y;
				   },
			   error: function(xhr, resp, text) {
			       console.log(xhr, resp, text);
			   }
		});
		return bot;
	}
	
	function askEnvRobot(){
		$.ajax({
			   url: '/envRobot', 
			   type : 'GET', 
			   dataType : 'JSON', 
		       async: false,
		        cache: false,   // //WTF IS THIS
		        timeout: 30000,
			   // contentType:'application/json',
			   success : function(data/* , textStatus */) {
				   robot = setRobotCoord(); // marche mais ne s'aplique pas
				   // change response to correspond rerenderall()
				   knownEnv = treatForRerenderall(data);
				   // add paths to the env
				   knownEnv = generatePaths(knownEnv);
				   knownEnv = addRobotToMap(knownEnv);
				   // apply changes from checkbox
				   displayedEnv = cbChanges(knownEnv);
				   
				   // Final Render
				   Display();
			   },
			   error: function(xhr, resp, text) {
			       console.log(xhr, resp, text);
			   }
			});
	}
	function addRobotToMap(knownEnv){
		knownEnv.data[robot.x + sizemap * robot.y] = imgCodeRobot;
		return knownEnv;
	}
	
	function askMove(dir){
		$.ajax({
			   url: '/robot/state',
			   type : 'GET', 
			   dataType : 'text', 
			   // contentType:'application/json',
			   success : function(data) {
				   console.log("data",data);
				   console.log("id",id);
				  if (data == id) {
					  $.ajax({
						   url: '/cmd/' + dir, 
						   type : 'GET', 
						   dataType : 'text', 
						   // contentType:'application/json',
						   success : function() {
							   // add new path to db
							   addPath(); 
							   askEnvRobot();
						   },
						   error: function(xhr, resp, text) {
						       console.log(xhr, resp, text);
						   }
						});
				  }
				  else {
					  alert("commande non autorisée");
				  }
			   },
			   error: function(xhr, resp, text) {
			       console.log(xhr, resp, text);
			   }
			});	
	}
	
	function addPath(dir){
		robot = setRobotCoord();
			
		var path = { x:parseInt(robot.getX()),
		     	 	y:parseInt(robot.getY())} ;
		$.ajax({
		   url: '/paths', 
		   type : 'POST', 
		   dataType : 'text', 
		   contentType: 'application/json',
		   data : JSON.stringify(path) ,
		   success : function(data,textStatus) {
		       console.log("success : ", data, textStatus);
		   },
		   error: function(xhr, resp, text) {
		       console.log(xhr, resp, text);
		   }
		})
	}
	
	function generatePaths(env){
		$.ajax({
		       url : '/paths',
		       type : 'GET',
		       dataType : 'JSON', 
		        data : 	JSON.stringify(),
		       success : function(response, statut){ 
		           for (const arr of response) {
		               env.data[arr.x - 1 + sizemap * (arr.y - 1)] = 126;
		        	 }
		       },
	
		       error : function(resultat, statut, erreur){
		           console.log(erreur);
		       }
	    });
		return env;
	}
	
	function deletePaths(){
		$.ajax({
		       url : '/paths',
		       type : 'DELETE',
		       dataType : 'JSON', 
		      	data : 	JSON.stringify(),
		       success : function(){ 
		           console.log("yes");
		       },
	
		       error : function(erreur){
		           console.log(erreur);
		       }
	 });
	}
	
	function treatForRerenderall(data){
	    let l = mapMng.data.layers[0];
	    for (const key of Object.keys(data)) {
	    	let coord = key.split(',');
	    	let x = parseInt(coord[0]);
	    	let y = parseInt(coord[1]);
	    	let cell = l.data[x + sizemap * y];
	    	switch(data[key]){
		    	case "OBSTACLE": // Obstacle
					l.data[x + sizemap * y] = imgCodeObstacle;
		    		break;
				case "FREE": // free
		            l.data[x + sizemap * y] = imgCodeFree;
		    		break;
				case "UNKNOWN": // unknown
				default:
		            l.data[x + sizemap * y] = imgCodeUnknown;
					break;
	    	}
	 	}
	    return l;
	}
	
	function cbChanges(list){
		displayedEnv = mapMng.data.layers[0];
		
		applycbRobot(cbShRobot.checked, list);
		applycbPath(cbShPath.checked, list);
		applycbObstacle(cbShObstacle.checked, list);
		return displayedEnv;
	}
	function applycbObstacle(bool, knownEnv){
		if(!bool){
			for (var i = 0; i < knownEnv.data.length; i++) {
		    	if(knownEnv.data[i] == imgCodeObstacle && displayedEnv.data[i] == imgCodeObstacle){
		    		displayedEnv.data[i] = imgCodeFree;
		    	}
			}
		}
		else{
			for (var i = 0; i < knownEnv.data.length; i++) {
		    	if(knownEnv.data[i] == imgCodeObstacle && displayedEnv.data[i] != imgCodeObstacle){
		    		displayedEnv.data[i] = imgCodeObstacle;
		    	}
			}
		}
	}
	function applycbPath(bool, knownEnv){
		if(bool){
			if(isIterable(displayedEnv)){
			    for (const cell of displayedEnv) {
			    	if(cell == imgCodePathV 
			        	|| cell == imgCodePathH
			        	|| cell == imgCodePathUpLeft
			        	|| cell == imgCodePathLeftDown
			        	|| cell == imgCodePathDownRight
			        	|| cell == imgCodePathRightUp){
			    		cell = imgCodeUnknown;
			    	}
			    }
		    }
		}
		
	}
	function applycbRobot(bool, knownEnv){
		if(bool){
			if(isIterable(displayedEnv)){
			    for (const cell of displayedEnv) {
			    	if(cell == imgRobot){
			    		cell = imgCodeUnknown;
			    	}
			    }
		    }
		}
		else{
			var i = 0;
			// while car on sait qu'il n'y a qu'un robot dans env
			while(!stop && i < knowEnv.length){
				if(knownEnv[i] == imgCodeRobot){
					displayedEnv[i] = imgCodeRobot;
					stop = true;
				}
				i++;
			}
		}
	}
	
	
	function Display(){
	   mapMng.data.layers[0] = displayedEnv;
	   mapMng.rerenderall();
	}
	
	function isIterable(obj) {
		  // checks for null and undefined
		  if (obj == null) {
		    return false;
		  }
		  return typeof obj[Symbol.iterator] === 'function';
		}
	function lireCookie(nom){ 
  	    var nomEtEgal = nom + '=';
  	    var cTableau = document.cookie.split(';');
  	    for(var i=0;i<cTableau.length;i++){
  	        var c = cTableau[i];
  	        while (c.charAt(0)==' ') c = c.substring(1,c.length);
  	        if (c.indexOf(nomEtEgal) == 0) return c.substring(nomEtEgal.length,c.length);
  	    }
  	    return null;
  	}
	
	function toggleDisplayOn(elmt)
	{
	   if(typeof elmt == "string")
		   elmt = document.getElementById(elmt);
	   elmt.style.display = "";
	}
	
	function toggleDisplayOff(elmt)
	{
	   if(typeof elmt == "string")
		   elmt = document.getElementById(elmt);
	   elmt.style.display = "none";
	}
});