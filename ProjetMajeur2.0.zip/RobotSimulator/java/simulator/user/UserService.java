package simulator.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	/**
	 * Return all the users in database
	 * @return
	 */
	public List<User> getAllUser() {
		List<User> users = new ArrayList<>();
		userRepository.findAll().forEach(users::add);
		return users;
	}
	/**
	 * Return User by id
	 * @param id
	 * @return
	 */
	public User getUserById(Integer id) {
		return userRepository.findById(id);
	}
	
	/**
	 * Add user to database
	 * @param user
	 * @return
	 */
	public void addUser(User user) {
		userRepository.save(user);
	}
}
