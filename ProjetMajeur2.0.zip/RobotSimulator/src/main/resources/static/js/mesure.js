$(document).ready(function(){
	
//$("#refresh").click(function(){
setInterval(getMesure,5000);
//	});  
    
});


function graph1(){
	
	var myContext1 = document.getElementById("myChart_cmd").getContext('2d');
	var myChartConfig1 = {
			type: 'line',
			  data: {
			    labels: label,
			    datasets: [{
			      label: 'number of command',
			      data: cmd,
			      backgroundColor: "rgba(255,240,51,0.6)"
			    }, ]
		}
	}
	var myChart_cmd = new Chart(myContext1, myChartConfig1);	
}

function graph2(){
	
	var myContext2 = document.getElementById("myChar_dist");
	var myChartConfig2 = {
			type: 'line',
			  data: {
			    labels: label,
			    datasets: [{
	       label: "distance parcourue",
	       data: distance,
	       backgroundColor: "rgba(255,240,51,0.6)"
	       }, ]
	  	}
	}
	var myChar_dist = new Chart(myContext2, myChartConfig2);	
}

function graph3(){
	
	var myContext3 = document.getElementById("myChart_obs_nb");
	var myChartConfig3 = {
			type: 'line',
			  data: {
			    labels: label,
			    datasets: [{
	       label: "Nombre d'obstacle passé",
	       data: obs,
	       backgroundColor: "rgba(255,240,51,0.6)"
	       }, ]
	  	}
	}
	var myChart_obs_nb = new Chart(myContext3, myChartConfig3);	
}

function graph4(){
	
	var myContext4 = document.getElementById("myChart_visible_obs_nb");
	var myChartConfig4 = {
			type: 'line',
			  data: {
			    labels: label,
			    datasets: [{
	       label: "Nombre d'obstacle visible",
	       data: obs_vue,
	       backgroundColor: "rgba(255,240,51,0.6)"
	       }, ]
	  	}
	}
	var myChart_visible_obs_nb = new Chart(myContext4, myChartConfig4);	
}



var cmd = new Array();
var obs = new Array();
var obs_vue = new Array();
var distance = new Array();
var label = new Array();

function getMesure(){
	cmd = []; 
	obs = []; 
	obs_vue = []; 
	distance = []; 
	label = [];
	
	$.ajax({
	   	url : '/mesure'  ,
		type : 'GET',
	   	dataType : 'JSON',
	   	data : 	JSON.stringify(),
	   	success : function(data, statut){
	   		console.log(data)
	   			for (var i = 0; i < data.length; i++) {
	   				
	   		   		$('#cmds_nb_Id')[0].innerText=data[i].cmdsNb;
	   		   		$('#dist')[0].innerText=data[i].dist;
	   		   		$('#obs_nb')[0].innerText=data[i].obs_nb;
	   		   		$('#visible_obs_nb')[0].innerText=data[i].visible_obs_nb;
	   		   		
	   		   		cmd.push(data[i].cmdsNb);
	   		   		obs.push(data[i].obs_nb);
	   		   		obs_vue.push(data[i].visible_obs_nb);
	   		   		distance.push(data[i].dist);
	   		   		label.push(i);
		   		   	graph1()
		   	    	graph2()
		   	    	graph3()
		   	    	graph4()
	   		   		
	   		   		
	   				
	   			} 
	   			
	   	},
	
	   	error : function(resultat, statut, erreur){
 			alert("error");	
	}});		
}

