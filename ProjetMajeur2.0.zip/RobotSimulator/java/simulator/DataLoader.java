package simulator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import simulator.admin.Admin;
import simulator.admin.AdminRepository;
import simulator.env.Environment;
import simulator.env.EnvironmentRepository;
import simulator.robot.Robot;
import simulator.robot.RobotRepository;

@Component
public class DataLoader implements ApplicationRunner {

    private AdminRepository adminrep;
    private EnvironmentRepository envRep;
    private RobotRepository robotRep;
    @Autowired
    public DataLoader(AdminRepository adminrep,EnvironmentRepository envRep,RobotRepository robotRep) {
        this.adminrep = adminrep;
        this.envRep = envRep;
        this.robotRep = robotRep;
    }

    public void run(ApplicationArguments args) {
//    	adminrep.save(new Admin("admin", "admin"));
//    	envRep.save(new Environment()) ;
//    	robotRep.save(new Robot());
    	
    }
}
