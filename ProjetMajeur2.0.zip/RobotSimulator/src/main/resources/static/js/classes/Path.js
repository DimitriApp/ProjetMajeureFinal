class Path {
    // méthode constructor
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }

    sayCoord() {
        return `${this.x} ${this.y}`;
    }

    getX()
    {
        return `${this.x}`;
    }getY()
    {
        return `${this.y}`;
    }
    setX(x)
    {
        this.x = x;
    }setY(y)
    {
        this.y = y;
    }
}


export {Path};