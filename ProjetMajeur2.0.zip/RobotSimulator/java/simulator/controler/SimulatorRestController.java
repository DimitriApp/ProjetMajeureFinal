package simulator.controler;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import simulator.env.Cell;
import simulator.env.Point;
import simulator.measure.Measure;

/**
 * Rest Controller of Simulator : user can : move the robot and get his
 * environment // administrator can initialize the simulator
 * 
 * @author mathieu lai-king
 *
 */
@RestController
public class SimulatorRestController {
	
	@Autowired
	private SimulatorService simulatorService;

	@RequestMapping("/init")
	private void init() {
		simulatorService.init();
	}

	@RequestMapping("/cmd/{cmd_key}")
	private boolean applyMvt(@PathVariable String cmd_key) {
		System.out.println(cmd_key);
		return simulatorService.applyMvt(cmd_key);
		
	}

	@RequestMapping("/envRobot")
	private Map<Point, Cell> getEnvRobot() {
		return simulatorService.getRobotEnv().getMap();
	}
	
	@RequestMapping(value="/mesure")
	public List<Measure> getMesure() {
		return simulatorService.getMesure();
	}

	
	/**
	 * Get state of robot
	 * @param user
	 */
	@RequestMapping(method=RequestMethod.GET,value="/robot/state")
	public String getStateRobotById() {
		return simulatorService.getStateById(1);
	}

	/**
	 * Change state of robot in database
	 * @param robot
	 */
	@RequestMapping(method=RequestMethod.PUT,value="/robot")
	public void change_state_robot(@RequestBody String state) {
		simulatorService.changeStateRobot(state);
	}
	
	
	@RequestMapping(method=RequestMethod.GET,value="/robots/coords")
	public Point getRobotCoord() {
		return simulatorService.getRobotCoord();
		
	}

}