package simulator.path;

import org.springframework.data.repository.CrudRepository;

public interface PathRepository extends CrudRepository<Path,Integer> {
}
