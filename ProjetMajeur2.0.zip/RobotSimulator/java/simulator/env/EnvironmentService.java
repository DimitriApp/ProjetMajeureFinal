package simulator.env;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Services on Environment database
 * 
 * @author mattk
 *
 */
@Service
public class EnvironmentService {

	@Autowired
	private EnvironmentRepository envRep;

	/**
	 * Add real environment
	 */
	public Environment initadd() {
		if (envRep.findOne(1) == null) {
			return envRep.save(new Environment());
		} else {
			return null;
		}
	}
	
	/**
	 * @return real env (id=1) obstacle number
	 */
	public int getRealEnvObsNb() {
		return envRep.findOne(1).getObsNb();
	}
	
	/**
	 * @return real environment
	 */
	public Environment getRealEnv() {
		return envRep.findOne(1);
	}
	
	
}
