package simulator.env;

import javax.persistence.Embeddable;

/**
 * This class represents a Key Point (2 Integers key) 
 * Can be placed in a Map as the Key 
 * @author mathieu lai-king
 *
 */
@Embeddable
public class Point {

    private final int x;
    private final int y;
    
    public Point() {
    	this.x=0;
    	this.y=0;
    }
    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Point)) return false;
        Point key = (Point) o;
        return x == key.x && y == key.y;
    }

    public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	@Override
    public int hashCode() {
        int result = x;
        result = 31 * result + y;
        return result;
    }
	
	@Override
	public String toString() {
		return x + "," + y;
	}

}
