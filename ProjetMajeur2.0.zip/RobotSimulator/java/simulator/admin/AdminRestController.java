package simulator.admin;



import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminRestController {
	

	@Autowired
	private AdminService adminService;
	
	
	/**
	 * Get admin in database
	 * @param admin
	 */
	@RequestMapping(method=RequestMethod.GET,value="/admin/{id}")
	public Admin addAdmin(@PathVariable int id) {
		return adminService.getAdminById(id);
	}
	
	
	/**
	 * Add admin in database
	 * @param admin
	 */
	@RequestMapping(method=RequestMethod.POST,value="/admin")
	public String addAdmin(@RequestBody Admin admin) {
		boolean adminNotInDb=adminService.addAdmin(admin);
		if (adminNotInDb) {
			return admin.getId().toString();
		}
		else {
			return "error";
		}
	}
	
	/**
	 * Log in the admin if the id and password are accurate
	 * @param admin
	 * @param session
	 * @param modelMap
	 */
	@RequestMapping(value = "/admin/login", method = RequestMethod.POST)
	public String login(@RequestBody Connection connection,HttpSession session) {
		
		String dataret = "";
		if(adminService.possibleAdminConnect(connection.getName(),connection.getPassword())) {
			System.out.println("name :" + connection.getName() + "psswd:"+connection.getPassword());
			session.setAttribute("username", connection.getName());
			dataret = "../adminpage.html";
		} 
		else {
			dataret = "../adminlogin.html";
		}
		return dataret;
	}	
}