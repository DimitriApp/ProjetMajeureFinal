$(document).ready(function(){ 
	
		$("#init").click(function() {
			$.ajax({ 
		        method:'GET',
				url:'/init',
		        dataType:'text'	,
	        	success: function (response) {
              		toggleDisplayOff("started");
              		toggleDisplayOn("stopped");
              	}
			});
		});	
		
		try {
			$.ajax({ 
	            method:'GET',
	    		url:'/robot/state',
	            dataType:'text',
	            success: function (response) {
	              	console.log(response) //state robot
	              	if (response=="enable"){ //if robot enable: change state for others+show running
	              		toggleDisplayOn("started");
	              		toggleDisplayOff("stopped");
	              	}
	              	else{
	              		toggleDisplayOff("started");
	              		toggleDisplayOn("stopped");
	              	}
	            }
			});
		}
		catch(error) {
			console.log("robot pas encore crée")
		}
	
	//Back home if button pressed
	$("#home").click(function(){
	        document.location.href="http://localhost:8080"
	});
	
	//Robot enable if button pressed
  	$("#startcommand").click(function(){
 		$.ajax({ 
            method:'PUT',
    		url:'/robot', 
            data : 'enable', //enable robot
            contentType:'text/plain',
            success: function () {
            	console.log("Success enable");
          		toggleDisplayOn("started");
          		toggleDisplayOff("stopped");
            },
            error: function (xhr, ajaxOptions, thrownError) {
            	console.log(xhr, ajaxOptions, thrownError);
            	console.log("Error");
            }
        }); 
    });  
  	
  	//Robot disable if button pressed
  	$("#stopcommand").click(function(){
  		$.ajax({ 
            method:'PUT',
    		url:'/robot', 
            data : 'disable', //disable robot
            contentType:'text/plain',
            success: function () {
            	console.log("Success disable");
      			toggleDisplayOn("stopped");
      			toggleDisplayOff("started");
            },
            error: function (xhr, ajaxOptions, thrownError) {
            	console.log(xhr, ajaxOptions, thrownError);
            	alert("Error");
            }
        }); 
    }); 
  	
	function toggleDisplayOn(elmt)
	{
	   if(typeof elmt == "string")
		   elmt = document.getElementById(elmt);
	   elmt.style.display = "";
	}
	
	function toggleDisplayOff(elmt)
	{
	   if(typeof elmt == "string")
		   elmt = document.getElementById(elmt);
	   elmt.style.display = "none";
	}
});