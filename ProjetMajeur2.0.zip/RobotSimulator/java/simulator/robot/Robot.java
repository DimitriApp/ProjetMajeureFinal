package simulator.robot;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import simulator.env.Cell;
import simulator.env.Environment;
import simulator.env.Point;

/**
 * This class entity represents a robot in the simulator
 * 
 * @author mathieu lai-king
 *
 */
@Entity
public class Robot {

	/*
	 * Attributs
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private Orientation orientation;

	@Embedded
	private Point coords;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "discovered_env_id")
	private Environment discoveredEnv;
	
	private String state;

	/*
	 * Constructors
	 */
	public Robot() {
		this.orientation = Orientation.E;
		this.coords = new Point(0, 0);
		this.discoveredEnv = initEnv();
		this.state = "disable";
	}

	public Robot(Orientation orientation, Point coords) {
		this.orientation = orientation;
		this.coords = coords;
		this.discoveredEnv = initEnv();
		this.state = "disable";
	}

	/*
	 * Getters and Setters
	 */

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setDiscoveredEnv(Environment discoveredEnv) {
		this.discoveredEnv = discoveredEnv;
	}

	public Environment getDiscoveredEnv() {
		return this.discoveredEnv;
	}

	public Orientation getOrientation() {
		return orientation;
	}

	public Point getCoords() {
		return coords;
	}

	public boolean setCoords(Point point) {
		boolean ret = false;
		if ((point.getX() >= 0 && point.getX() <= this.getDiscoveredEnv().getGridSize())
				&& (point.getY() >= 0 && point.getY() <= this.getDiscoveredEnv().getGridSize())) {
			this.coords = point;
			ret = true;
		}
		return ret;
	}

	public Vision getVision() {
		return new Vision(this.coords, this.orientation);
	}

	public void setOrientation(Orientation o) {
		this.orientation = o;
	}

	/*
	 * Methods
	 */

	public Environment initEnv() {
		Environment initenv = new Environment(0);
		for (int i = 0; i < initenv.getGridSize(); i++) {
			for (int j = 0; j < initenv.getGridSize(); j++) {
				if (i == this.coords.getX() && j == this.coords.getY()) {
					initenv.put(i, j, Cell.FREE);
				} else {
					initenv.put(i, j, Cell.UNKNOWN);
				}
			}
		}
		return initenv;
	}

}
