package simulator.path;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class PathRestController {
	
	@Autowired
	private PathService pathService;
	
	@RequestMapping("/paths")
	private List<Path> getAllCourses() {
		List<Path> lp = pathService.getAllPath();
		return lp;

	}
	@RequestMapping(method=RequestMethod.POST,value="/paths")
	public void addPath(@RequestBody Path path) {
		//path = new Path(path.getX(), path.getY());
		pathService.addPath(path);
	}
	/*
	@RequestMapping("/paths/{id}")
	private Optional<Path> getPath(@PathVariable String id) {
		Optional<Path> op = pathService.getPath(id);
		return op;
	}*/

	/*
	@RequestMapping(method=RequestMethod.POST,value="/paths/{x}/{y}")
	public void addPath(@RequestBody Path path, @PathVariable String x, @PathVariable String y) {
		path = new Path(Integer.parseInt(x), Integer.parseInt(y));
		pathService.addPath(path);
	}*/
	/*
	@RequestMapping(method=RequestMethod.PUT,value="/paths/{id}")
	public void updatePath(@RequestBody Path path,@PathVariable String id) {
		path.setId(Integer.valueOf(id));
		pathService.updatePath(path);
	}
	*/
	@RequestMapping(method=RequestMethod.DELETE,value="/paths/{id}")
	public void deletePath(@PathVariable int id) {
		pathService.deletePath(id);
	}
	@RequestMapping(method=RequestMethod.DELETE,value="/paths")
	public void deletePath() {
		pathService.deleteAll();
	}
}
