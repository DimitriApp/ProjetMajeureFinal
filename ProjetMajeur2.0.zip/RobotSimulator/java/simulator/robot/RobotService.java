package simulator.robot;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import simulator.env.Cell;
import simulator.env.Environment;
import simulator.env.Point;

/**
 * Services on the Robot database
 * 
 * @author mathieu lai-king
 *
 */
@Service
public class RobotService {

	@Autowired
	private RobotRepository botRep;

	/**
	 * @return list of robots in db
	 */
	public List<Robot> getAllRobots() {
		List<Robot> robots = new ArrayList<>();
		botRep.findAll().forEach(robots::add);
		return robots;
	}

	/**
	 * @param id : id of robot
	 * @return robot if id in database, null if not
	 */
	public Robot getById(Integer id) {
		return botRep.findById(id);
	}

	/**
	 * Add robot in database if table empty
	 * 
	 * @return Robot object added
	 */
	public Robot addRobot() {
		if (this.getAllRobots().isEmpty()) {
			return botRep.save(new Robot());
		} else {
			return null;
		}
	}

	/**
	 * Modify the robot in the db
	 * 
	 * @param robot : new robot
	 */
	public Robot updateRobot(Robot robot) {
		return botRep.save(robot);
	}

	/**
	 * Update the robot's environment giving the real environment and his vision
	 * 
	 * @param realEnv
	 */
	public void updateEnv(Environment realEnv) {
		Robot r = this.getById(1);
		Environment robotEnv = r.getDiscoveredEnv();
		Vision vision = new Vision(r.getCoords(), r.getOrientation());

		for (int i = 0; i < realEnv.getGridSize(); i++) {
			for (int j = 0; j < realEnv.getGridSize(); j++) {
				Point p = new Point(i, j);
				if (vision.getVisiblePts().contains(p) && robotEnv.getCellContent(i, j).equals(Cell.UNKNOWN)) {
					robotEnv.put(i, j, realEnv.getCellContent(i, j));
				}
			}
		}
		r.setDiscoveredEnv(robotEnv);
		this.updateRobot(r);
	}

	/**
	 * @return robot's number of visible obstacle
	 */
	public int getVisibleObs() {
		return this.getById(1).getDiscoveredEnv().getObsNb();
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public String getStateById(Integer id) {
		Robot robot = getById(1);
		return robot.getState();
	}

	/**
	 * Change state of robot
	 * 
	 * @param state
	 */
	public void changeStateRobot(String state) {
		Robot r = getById(1);
		r.setState(state);
		updateRobot(r);
	}
}
