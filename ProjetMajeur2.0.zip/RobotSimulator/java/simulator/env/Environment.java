package simulator.env;

import java.util.Formatter;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * This class represents an environment , which is a Map with cells (cell enum)
 * generated randomly cells can be FREE,OBSTACLE or UNKNOWN
 * 
 * @author mattk
 *
 */
@Entity
public class Environment {
	/*
	 * Attributes
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	private int gridSize;
	private double obstacleRate;

	@ElementCollection
	private Map<Point, Cell> map;

	/*
	 * Constructors
	 */
	public Environment() {
		super();
		this.gridSize = 8;
		this.obstacleRate = 0.2;
		this.map = this.generate();
	}

	public Environment(double obstacleRate) {
		super();
		this.gridSize = 8;
		this.obstacleRate = obstacleRate;
		this.map = this.generate();
	}

	public Environment(int gridSize, double obstacleRate) {
		super();
		this.gridSize = gridSize;
		this.obstacleRate = obstacleRate;
		this.map = this.generate();
	}

	/*
	 * Getters/Setters
	 */
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public double getObstacleRate() {
		return obstacleRate;
	}

	public void setObstacleRate(double obstacleRate) {
		this.obstacleRate = obstacleRate;
	}

	public void setGridSize(int gridSize) {
		this.gridSize = gridSize;
	}

	public Map<Point, Cell> getMap() {
		return map;
	}

	public void setMap(Map<Point, Cell> map) {
		this.map = map;
	}

	public int getGridSize() {
		return gridSize;
	}

	/*
	 * Methods
	 */

	/**
	 * Generate String matrix with 'x' for obstacle and 'o' for free case
	 * 
	 * @return String matrix of obstacle or free case
	 */
	private Map<Point, Cell> generate() {
		Map<Point, Cell> env = new HashMap<Point, Cell>();
		for (int i = 0; i < gridSize; i++) {
			for (int j = 0; j < gridSize; j++) {
				if (Math.random() <= this.obstacleRate) {
					env.put(new Point(i, j), Cell.OBSTACLE);
				} else {
					env.put(new Point(i, j), Cell.FREE);
				}
			}
		}
		return env;
	}

	/**
	 * Put cell c at the specified coordinates (x,y) in the env map
	 * 
	 * @param x
	 * @param y
	 * @param c
	 */
	public void put(int x, int y, Cell c) {
		this.map.put(new Point(x, y), c);
	}

	/**
	 * Return state of cell of the matrix
	 * 
	 * @param x : horizontal coord of cell
	 * @param y : vertical coord of cell
	 * @return Cell state at the specified coordinates
	 */
	public Cell getCellContent(int x, int y) {
		return map.get(new Point(x, y));
	}

	/**
	 * Generate String matrix with 'x' for obstacle and 'o' for free case "?" for
	 * unknown or null
	 * 
	 * @return String matrix of obstacle or free case
	 */
	public String[][] stringMatrix() {
		String[][] env = new String[gridSize][gridSize];
		for (int i = 0; i < gridSize; i++) {
			for (int j = 0; j < gridSize; j++) {
				if (this.getCellContent(i, j) == Cell.OBSTACLE) {
					env[i][j] = "x";
				} else if (this.getCellContent(i, j) == Cell.FREE) {
					env[i][j] = "o";
				} else {
					env[i][j] = "?";
				}
			}
		}
		return env;
	}

	/**
	 * Gives a string representation of the environment string array
	 * 
	 * @param matrix String matrix (double array)
	 * @param sizeX  : x size of matrix
	 * @param sizeY  : y size of matrix
	 * @return String representing the matrix
	 */
	public static String printMatrix(String[][] matrix, int sizeX, int sizeY) {
		StringBuilder sb = new StringBuilder();
		@SuppressWarnings("resource")
		Formatter formatter = new Formatter(sb, Locale.FRENCH);
		String formatS = "%1$5s";
		String[] valueTab = new String[sizeX + 1];
		valueTab[0] = "";
		for (int index = 0; index < sizeX; index++) {
			formatS = formatS + " %" + (index + 2) + "$5s";
			valueTab[index + 1] = String.valueOf(index);
		}
		formatter.format(formatS + "\n", valueTab);
		formatter.format("%1$5s | %2$47s\n", "", "_______________________________________________");
		for (int i = 0; i < sizeY; i++) {
			String formatS2 = "%1$5s | ";
			String[] valueTab2 = new String[sizeY + 1];
			valueTab2[0] = String.valueOf(i);
			for (int j = 0; j < sizeX; j++) {
				formatS2 = formatS2 + " %" + (j + 2) + "$5s";
				valueTab2[j + 1] = matrix[i][j];
			}
			formatter.format(formatS2 + "\n", valueTab2);
		}
		return formatter.toString();
	}
	
	/**
	 * @return number of Cell's that are OBSTACLE
	 */
	public int getObsNb() {
		int cpt = 0;
		for (int i = 0; i < gridSize; i++) {
			for (int j = 0; j < gridSize; j++) {
				if (this.getCellContent(i, j) == Cell.OBSTACLE) {
					cpt++;
				}
			}
		}
		return cpt;
	}

}
