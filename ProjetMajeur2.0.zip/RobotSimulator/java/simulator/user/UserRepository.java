package simulator.user;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<User, Integer>{
	public User findByState(String state);
	public User findById(Integer id);
}

