
$(document).ready(function(){    
  $("#cancel").click(function(){
   document.location.href="http://localhost:8080"
 });  


  $("#submit").on('click', function(){

    var login = { name:$("#name").val(),
    password:$("#password").val()} ;

    $.ajax({
      url: '/admin/login', 
      type : 'POST',
      dataType : 'text', 
      contentType:'application/json',
      data : JSON.stringify(login) ,
      success : function(data,textStatus) {
    	  window.location.replace(data)
    	  console.log(data);
     },
      error: function(xhr, resp, text) {
    	  console.log("erreur dans la tentative de connexion");
    	  console.log(xhr, resp, text);
      }
    })
  });
});