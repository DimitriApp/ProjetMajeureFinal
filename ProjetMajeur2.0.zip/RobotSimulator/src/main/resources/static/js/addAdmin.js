$(document).ready(function(){ 
	
  	$("#cancel").click(function(){
        //alert("Cancel button clicked ");
        document.location.href="http://localhost:8080"
    });  

	
	/*
	 * Input variables 
	 */    
	var $name = $('#name'),
	    $password = $('#password'),
	    $repassword = $('#repassword'),
	    $erreur = $('#erreur')
	
	
	$repassword.keyup(function(){ // test 2nd password input equal to first password input
	    if($(this).val() != $password.val()){
	        $(this).css({ 
		    borderColor : 'red',
		    color : 'red'
	        });
	    }
	    else{
		$(this).css({
		    borderColor : 'green',
		    color : 'green'
		});
	    }
	});

    $("#submit").click(function(){ // submit form
    	
    	var test = []; // to ensure the 4 domains are filled
    	test.push(verify($name));
        test.push(verify($password));
        test.push(verify($repassword));
        
        var i=0; // count for the good domains
        while(test[i]){
        	i+=1 
            console.log("blo");

        }
    	
    	var signupinfo = {name:$("#name").val(), 
            password : $("#password").val()}
    	
    	if (i==3) { // if all the domains are filled then post the form
	        $.ajax({ 
	            method:'POST',
	    		url:'/admin', 
	            data : JSON.stringify(signupinfo), 
	            dataType:'text',
	            contentType:'application/json',
	            success: function (response) {
	            	console.log(response);
	            	if (response == "error") {
	            		alert("Nom d'utilisateur déja pris");
	            	}
	            	else {
	            		alert("Details saved successfully!!!");
	            		}
	            },
	            error: function (xhr, ajaxOptions, thrownError) {
	            	alert("Error");
	            }
	        }); 
    	}
    	else {
    		alert("Champs non remplis")
    		
    	}
    });
    
    function verify(champ){
    	var test = true;
        if(champ.val() == ""){ 
        	$erreur.css('display', 'block'); 
            champ.css({ 
        	    borderColor : 'red',
        	    color : 'red'
        	});
            test=false;
        }
        return test;
    }
}); 
