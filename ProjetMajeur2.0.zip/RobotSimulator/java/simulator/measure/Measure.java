package simulator.measure;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Measure {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private int cmdsNb;
	private int obs_nb;
	private int visible_obs_nb;
	private int dist;
	
	public Measure() {
		this.cmdsNb = 0; 
		this.dist = 0; 
		this.obs_nb = 0; 
		this.visible_obs_nb = 0; 
	}

	public Measure(int cmdsNb, int obs_nb, int visible_obs_nb, int dist) {
		this.cmdsNb = cmdsNb;
		this.obs_nb = obs_nb;
		this.visible_obs_nb = visible_obs_nb;
		this.dist = dist;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public int getCmdsNb() {
		return cmdsNb;
	}
		
	public int getDist() {
		return dist;
	}

	public int getVisible_obs_nb() {
		return visible_obs_nb;
	}

	public void setVisible_obs_nb(int visible_obs_nb) {
		this.visible_obs_nb = visible_obs_nb;
	}

	public int getObs_nb() {
		return obs_nb;
	}

	public void setObs_nb(int obs_nb) {
		this.obs_nb = obs_nb;
	}

	public void setCmdsNb(int cmdsNb) {
		this.cmdsNb = cmdsNb;
	}

	public void setDist(int dist) {
		this.dist = dist;
	}
	

}
