package simulator.controler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import simulator.env.Cell;
import simulator.env.Environment;
import simulator.env.EnvironmentService;
import simulator.env.Point;
import simulator.measure.Measure;
import simulator.measure.MeasureService;
import simulator.robot.Orientation;
import simulator.robot.Robot;
import simulator.robot.RobotService;

/**
 * Services of a simulator , a simulator contains a Robot and an environment it
 * has to be initialized by the administrator
 * 
 * @author mathieu lai-king
 *
 */
@Service
public class SimulatorService {

	@Autowired
	private EnvironmentService envRep;

	@Autowired
	private RobotService botServ;
	
	@Autowired
	private MeasureService measServ;

	/**
	 * create robot and real environment
	 */
	public void init() {
		envRep.initadd();
		botServ.addRobot();
		botServ.updateEnv(envRep.getRealEnv());
		measServ.addMeasure(new Measure());
	}

	/**
	 * Apply the movement given by the specified cmdKey if possible
	 * If it is not possible , the robot just rotate to the given 
	 * orientation
	 * Update the measure table
	 * @param cmdKey
	 * @return true if the robot has moved
	 */
	public boolean applyMvt(String cmdKey) {
		boolean ret = false;
		int xAdd = 0;
		int yAdd = 0;
		Robot r = botServ.getById(1);
		Orientation orientation = null;
		Measure m = new Measure();
		
		m.setCmdsNb(measServ.getLastCmdCount() + 1);
		
		if (cmdKey.equals("up")) {
			orientation = Orientation.N;
			xAdd = 0;
			yAdd = -1;
		} else if (cmdKey.equals("down")) {
			orientation = Orientation.S;
			xAdd = 0;
			yAdd = 1;
		} else if (cmdKey.equals("left")) {
			orientation = Orientation.W;
			xAdd = -1;
			yAdd = 0;
		} else if (cmdKey.equals("right")) {
			orientation = Orientation.E;
			xAdd = 1;
			yAdd = 0;
		}
		
		r.setOrientation(orientation);
		botServ.updateRobot(r);
		botServ.updateEnv(envRep.getRealEnv());
		ret = this.move(xAdd, yAdd);
		if(ret) {
			m.setDist(measServ.getLastDist() + 1);
		}
		else {
			m.setDist(measServ.getLastDist());
		}
		m.setObs_nb(envRep.getRealEnvObsNb());
		m.setVisible_obs_nb(botServ.getVisibleObs());
		measServ.addMeasure(m);
		return ret;
	}

	/**
	 * Changes the robot's orientation with 'o' and his coords if possible
	 * @param xAdd
	 * @param yAdd
	 * @param o
	 * @return true if the robot has moved
	 */
	public boolean move(int xAdd, int yAdd) {
		boolean ret = false;
		Robot r = botServ.getById(1);
		int x = r.getCoords().getX();
		int y = r.getCoords().getY();
		if (r.getDiscoveredEnv().getCellContent(x + xAdd, y + yAdd) == Cell.FREE) {
			ret = r.setCoords(new Point(x + xAdd, y + yAdd));
			botServ.updateRobot(r);
			botServ.updateEnv(envRep.getRealEnv());
		}

		return ret;
	}
	
	/**
	 * @return Robot's discovered environment
	 */
	public Environment getRobotEnv() {
		Robot r = botServ.getById(1);
		return r.getDiscoveredEnv();
	}
	
	
	/**
	 * @return List of all measures in database
	 */
	public List<Measure> getMesure() {
		return measServ.getMesure();
	}
	
	/**
	 * get robot state
	 * @param i
	 * @return
	 */
	public String getStateById(int i) {
		return botServ.getStateById(i);
	}
	
	/**
	 * change robot state
	 * @param state
	 */
	public void changeStateRobot(String state) {
		botServ.changeStateRobot(state);
	}
	
	/**
	 * get robot coord
	 * @return
	 */
	public Point getRobotCoord() {
		return botServ.getById(1).getCoords();
	}
	
	
	
	
}
