package simulator.env;

import org.springframework.data.repository.CrudRepository;

public interface EnvironmentRepository extends CrudRepository<Environment, Integer> {
	public Environment findByObstacleRate(double obstacleRate);
}
