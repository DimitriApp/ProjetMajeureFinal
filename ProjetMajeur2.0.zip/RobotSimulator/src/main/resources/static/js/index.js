$(document).ready(function(){ 
  	$("#register").click(function(){
        //alert("Add admin button clicked ");
        document.location.href="http://localhost:8080/addAdmin.html"
    });  
  	
  	$("#login").click(function(){
        //alert("Login button clicked ");
        document.location.href="http://localhost:8080/adminlogin.html"
    });  
  	
  	$("#userobot").click(function(){
        //alert("Simulator button clicked ");
  		window.open("http://localhost:8080/cmd.html");
  	});
}); 