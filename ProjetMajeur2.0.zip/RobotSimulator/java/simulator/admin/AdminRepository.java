package simulator.admin;
import org.springframework.data.repository.CrudRepository;



public interface AdminRepository extends CrudRepository<Admin, Integer> {
	public Admin findByName(String name);
	public Admin findByNameAndPassword(String name,String password);
	public Admin findById(Integer id);
}
