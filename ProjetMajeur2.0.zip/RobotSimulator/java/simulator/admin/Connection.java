package simulator.admin;

public class Connection {
	
	private String name;
	private String password;
	
	public Connection() {
		this.name="";
		this.password="";
	}
	public Connection(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
