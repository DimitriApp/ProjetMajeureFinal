package simulator.path;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PathService {
	
	@Autowired
	private PathRepository pathRepository;

	public List<Path> getAllPath() {
		List<Path> cards = new ArrayList<>();
		pathRepository.findAll().forEach(cards::add);
		return cards;
	}

	public Path getPath(int id) {
		return pathRepository.findOne(id);
	}

	public void addPath(Path card) {
		pathRepository.save(card);
	}

	public void updatePath(Path card) {
		pathRepository.save(card);
	}

	public void deletePath(int id) {
		pathRepository.delete(Integer.valueOf(id));
	}
	
	public void deleteAll() {
		pathRepository.deleteAll();
	}
}
