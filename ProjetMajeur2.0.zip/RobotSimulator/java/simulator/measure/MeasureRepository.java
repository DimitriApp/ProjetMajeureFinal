package simulator.measure;

import org.springframework.data.repository.CrudRepository;

public interface MeasureRepository extends CrudRepository<Measure,Integer> {
	public Measure findTopByOrderByIdDesc();
}
