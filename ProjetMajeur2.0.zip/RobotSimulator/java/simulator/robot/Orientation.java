package simulator.robot;

/**
 * Enum representing an orientation
 * 
 * @author mathieu lai-king
 *
 */
public enum Orientation {
	N, E, S, W;
}
