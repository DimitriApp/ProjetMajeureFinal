package simulator.measure;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MeasureService {
	
	@Autowired
	private MeasureRepository measureRepository;

	public List<Measure> getMesure() {
		List<Measure> mesures = new ArrayList<>();
		measureRepository.findAll().forEach(mesures::add);
		return mesures;
	}
	
	public void addMeasure(Measure m) {
		measureRepository.save(m);
	}
	
	/**
	 * @return last command number 
	 */
	public int getLastCmdCount() {
		return this.getLast().getCmdsNb();
	}
	/**
	 * @return last dist
	 */
	public int getLastDist() {
		return this.getLast().getDist();
	}
	
	
	public Measure getLast() {
		return measureRepository.findTopByOrderByIdDesc();
	}
}