package simulator.robot;

import org.springframework.data.repository.CrudRepository;

public interface RobotRepository extends CrudRepository<Robot, Integer> {
	public Robot findById(int robotId);
}
